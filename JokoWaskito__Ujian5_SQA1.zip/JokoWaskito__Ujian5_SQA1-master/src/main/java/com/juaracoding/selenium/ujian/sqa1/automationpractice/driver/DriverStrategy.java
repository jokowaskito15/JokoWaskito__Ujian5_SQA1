package com.juaracoding.selenium.ujian.sqa1.automationpractice.driver;

import org.openqa.selenium.WebDriver;

public interface DriverStrategy {
	
	public WebDriver setStrategy();

}
